/**
 * Agents API Route
 * 
 * CRUD operations for AI agents
 */

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/agents - List all agents
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId') || 'demo-user';
    
    const agents = await db.agent.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
    });
    
    return NextResponse.json({
      success: true,
      agents: agents.map(a => ({
        id: a.id,
        name: a.name,
        description: a.description,
        status: a.status,
        version: a.version,
        createdAt: a.createdAt,
        updatedAt: a.updatedAt,
      })),
    });
  } catch (error) {
    console.error('[AGENTS_GET_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to fetch agents', code: 'E500' },
      { status: 500 }
    );
  }
}

// POST /api/agents - Create new agent
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, config, userId = 'demo-user' } = body;
    
    if (!name) {
      return NextResponse.json(
        { error: 'Agent name is required', code: 'E001' },
        { status: 400 }
      );
    }
    
    const defaultConfig = {
      model: 'gpt-4o',
      provider: 'openai',
      temperature: 0.7,
      maxTokens: 4096,
      skills: [],
      memory: {
        enabled: true,
        workingMemorySize: 50,
        episodicRetention: 90,
        semanticEmbedding: true,
        compressionEnabled: true,
      },
      security: {
        sandboxMode: true,
        allowedDomains: [],
        maxExecutionTime: 60000,
        maxMemoryMB: 256,
        requireApproval: ['critical'],
      },
      ...config,
    };
    
    const agent = await db.agent.create({
      data: {
        userId,
        name,
        description,
        config: JSON.stringify(defaultConfig),
        status: 'idle',
        version: '1.0.0',
      },
    });
    
    return NextResponse.json({
      success: true,
      agent: {
        id: agent.id,
        name: agent.name,
        description: agent.description,
        status: agent.status,
        version: agent.version,
        config: defaultConfig,
        createdAt: agent.createdAt,
      },
    });
    
  } catch (error) {
    console.error('[AGENTS_POST_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to create agent', code: 'E500' },
      { status: 500 }
    );
  }
}

// PUT /api/agents - Update agent
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, name, description, config, status } = body;
    
    if (!id) {
      return NextResponse.json(
        { error: 'Agent ID is required', code: 'E001' },
        { status: 400 }
      );
    }
    
    const updateData: Record<string, unknown> = {};
    if (name) updateData.name = name;
    if (description) updateData.description = description;
    if (config) updateData.config = JSON.stringify(config);
    if (status) updateData.status = status;
    
    const agent = await db.agent.update({
      where: { id },
      data: updateData,
    });
    
    return NextResponse.json({
      success: true,
      agent: {
        id: agent.id,
        name: agent.name,
        description: agent.description,
        status: agent.status,
        version: agent.version,
        updatedAt: agent.updatedAt,
      },
    });
    
  } catch (error) {
    console.error('[AGENTS_PUT_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to update agent', code: 'E500' },
      { status: 500 }
    );
  }
}

// DELETE /api/agents - Delete agent
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json(
        { error: 'Agent ID is required', code: 'E001' },
        { status: 400 }
      );
    }
    
    await db.agent.delete({ where: { id } });
    
    return NextResponse.json({ success: true });
    
  } catch (error) {
    console.error('[AGENTS_DELETE_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to delete agent', code: 'E500' },
      { status: 500 }
    );
  }
}
