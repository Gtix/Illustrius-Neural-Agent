/**
 * Skills API Route
 * 
 * CRUD operations for AI agent skills
 */

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET /api/skills - List skills
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const verified = searchParams.get('verified');
    const limit = parseInt(searchParams.get('limit') || '50');
    
    const where: Record<string, unknown> = { isActive: true };
    if (category) where.category = category;
    if (verified === 'true') where.isVerified = true;
    
    const skills = await db.skill.findMany({
      where,
      orderBy: [
        { downloads: 'desc' },
        { rating: 'desc' },
      ],
      take: limit,
    });
    
    return NextResponse.json({
      success: true,
      skills: skills.map(s => ({
        id: s.id,
        name: s.name,
        displayName: s.displayName,
        description: s.description,
        category: s.category,
        version: s.version,
        isVerified: s.isVerified,
        downloads: s.downloads,
        rating: s.rating,
        securityLevel: s.securityLevel,
        createdAt: s.createdAt,
      })),
    });
  } catch (error) {
    console.error('[SKILLS_GET_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to fetch skills', code: 'E500' },
      { status: 500 }
    );
  }
}

// POST /api/skills - Create new skill
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      name,
      displayName,
      description,
      category = 'general',
      code,
      schema,
      permissions = [],
      authorId,
    } = body;
    
    if (!name || !displayName || !description || !code) {
      return NextResponse.json(
        { error: 'Missing required fields', code: 'E001' },
        { status: 400 }
      );
    }
    
    // Validate skill code (basic security check)
    const dangerousPatterns = [
      /eval\s*\(/,
      /Function\s*\(/,
      /require\s*\(\s*['"]child_process['"]\s*\)/,
      /process\.exit/,
      /fs\.(?:unlink|writeFile)\s*\(\s*['"]\/(?:etc|var|usr)/,
    ];
    
    for (const pattern of dangerousPatterns) {
      if (pattern.test(code)) {
        return NextResponse.json(
          { error: 'Skill contains potentially dangerous code', code: 'E003' },
          { status: 400 }
        );
      }
    }
    
    const skill = await db.skill.create({
      data: {
        name,
        displayName,
        description,
        category,
        version: '1.0.0',
        code,
        schema: JSON.stringify(schema || {}),
        permissions: JSON.stringify(permissions),
        securityLevel: 'standard',
        isVerified: false,
        isActive: true,
        downloads: 0,
        rating: 0,
        authorId,
      },
    });
    
    return NextResponse.json({
      success: true,
      skill: {
        id: skill.id,
        name: skill.name,
        displayName: skill.displayName,
        description: skill.description,
        category: skill.category,
        version: skill.version,
        isVerified: skill.isVerified,
        createdAt: skill.createdAt,
      },
    });
    
  } catch (error) {
    console.error('[SKILLS_POST_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to create skill', code: 'E500' },
      { status: 500 }
    );
  }
}

// Execute a skill
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { skillId, input, agentId } = body;
    
    if (!skillId) {
      return NextResponse.json(
        { error: 'Skill ID is required', code: 'E001' },
        { status: 400 }
      );
    }
    
    const skill = await db.skill.findUnique({
      where: { id: skillId },
    });
    
    if (!skill || !skill.isActive) {
      return NextResponse.json(
        { error: 'Skill not found or inactive', code: 'E004' },
        { status: 404 }
      );
    }
    
    // Create execution record
    const execution = await db.skillExecution.create({
      data: {
        skillId,
        input: JSON.stringify(input),
        status: 'running',
        tokensUsed: 0,
      },
    });
    
    const startTime = Date.now();
    
    try {
      // Execute skill (simplified - in production use sandboxing)
      const executeFunc = new Function('args', 'context', `
        ${skill.code}
        return execute(args, context);
      `);
      
      const context = { agentId, timestamp: new Date().toISOString() };
      const result = await Promise.race([
        Promise.resolve(executeFunc(input || {}, context)),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Execution timeout')), 30000)
        ),
      ]);
      
      // Update execution record
      await db.skillExecution.update({
        where: { id: execution.id },
        data: {
          output: JSON.stringify(result),
          status: 'success',
          duration: Date.now() - startTime,
        },
      });
      
      // Increment download count
      await db.skill.update({
        where: { id: skillId },
        data: { downloads: { increment: 1 } },
      });
      
      return NextResponse.json({
        success: true,
        result,
        execution: {
          id: execution.id,
          duration: Date.now() - startTime,
        },
      });
      
    } catch (execError) {
      await db.skillExecution.update({
        where: { id: execution.id },
        data: {
          status: 'error',
          errorMessage: execError instanceof Error ? execError.message : 'Unknown error',
          duration: Date.now() - startTime,
        },
      });
      
      throw execError;
    }
    
  } catch (error) {
    console.error('[SKILLS_PUT_ERROR]', error);
    return NextResponse.json(
      { error: 'Failed to execute skill', code: 'E500' },
      { status: 500 }
    );
  }
}
