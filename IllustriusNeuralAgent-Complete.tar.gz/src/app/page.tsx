'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import {
  Bot,
  Send,
  Settings,
  Database,
  Zap,
  Shield,
  Activity,
  MessageSquare,
  Plus,
  Trash2,
  Copy,
  Check,
  Loader2,
  Sparkles,
  Brain,
  Clock,
  User,
  AlertCircle,
  CheckCircle,
  XCircle,
  Menu,
  X,
  TrendingUp,
  Target,
  Award,
  BookOpen,
  Cpu,
  Globe,
  Mail,
  MessageCircle,
  Phone,
  Share2,
  Star,
  Download,
  Search,
  Filter,
  MoreVertical,
  Play,
  Pause,
  RefreshCw,
  Eye,
  ThumbsUp,
  ThumbsDown,
  Lightbulb,
  Code,
  FileText,
  Image as ImageIcon,
  Music,
  Video,
  Calendar,
  Map,
  ShoppingBag,
  CreditCard,
  BarChart3,
  PieChart,
  LineChart,
  Wallet,
  Crown,
  Rocket,
  Heart,
  Flame,
  Zap as ZapIcon,
  Layers,
  Cog,
  Bell,
  Key,
  Users,
  Server,
  Cloud,
  Lock,
  Unlock,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
} from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: Date;
  tokenCount?: number;
  sentiment?: number;
}

interface Agent {
  id: string;
  name: string;
  avatar?: string;
  description?: string;
  status: 'idle' | 'running' | 'paused' | 'error';
  personality?: string;
  learningEnabled: boolean;
  autoImprove: boolean;
  createdAt: string;
  stats: {
    messagesCount: number;
    skillsCount: number;
    memoryItems: number;
    successRate: number;
    improvementScore: number;
  };
}

interface Skill {
  id: string;
  name: string;
  displayName: string;
  description: string;
  category: string;
  icon: string;
  isEnabled: boolean;
  isPublic: boolean;
  downloads: number;
  rating: number;
  successRate: number;
  price: number;
  version: string;
}

interface Memory {
  id: string;
  type: 'working' | 'episodic' | 'semantic' | 'procedural';
  category?: string;
  content: string;
  importance: number;
  confidence: number;
  accessCount: number;
  createdAt: Date;
}

interface Platform {
  id: string;
  name: string;
  icon: React.ReactNode;
  isConnected: boolean;
  messagesCount: number;
  lastSync?: Date;
}

interface LearningEvent {
  id: string;
  type: string;
  description: string;
  impact: number;
  timestamp: Date;
}

// ============================================================================
// PLATFORM ICONS
// ============================================================================

const platformIcons: Record<string, React.ReactNode> = {
  whatsapp: <Phone className="h-4 w-4" />,
  telegram: <Send className="h-4 w-4" />,
  discord: <MessageCircle className="h-4 w-4" />,
  slack: <Share2 className="h-4 w-4" />,
  email: <Mail className="h-4 w-4" />,
  web: <Globe className="h-4 w-4" />,
};

// ============================================================================
// MAIN COMPONENT
// ============================================================================

export default function HomePage() {
  // State
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [rightPanelOpen, setRightPanelOpen] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [activeTab, setActiveTab] = useState('skills');
  const [activeSettingsTab, setActiveSettingsTab] = useState('general');
  const [showSettings, setShowSettings] = useState(false);
  const [showMarketplace, setShowMarketplace] = useState(false);
  const [showAnalytics, setShowAnalytics] = useState(false);
  
  // Connection status
  const [connected, setConnected] = useState(true);
  
  // Agents
  const [agents, setAgents] = useState<Agent[]>([
    {
      id: '1',
      name: 'Neural Assistant',
      description: 'Your primary AI assistant with self-improvement capabilities',
      status: 'idle',
      personality: 'Helpful, precise, and always learning',
      learningEnabled: true,
      autoImprove: true,
      createdAt: new Date().toISOString(),
      stats: { messagesCount: 1247, skillsCount: 12, memoryItems: 834, successRate: 98.5, improvementScore: 23 },
    },
    {
      id: '2',
      name: 'Code Architect',
      description: 'Specialized in software development and code review',
      status: 'running',
      personality: 'Technical, thorough, and optimization-focused',
      learningEnabled: true,
      autoImprove: true,
      createdAt: new Date().toISOString(),
      stats: { messagesCount: 562, skillsCount: 8, memoryItems: 421, successRate: 99.1, improvementScore: 45 },
    },
  ]);
  const [activeAgent, setActiveAgent] = useState<Agent | null>(agents[0]);
  
  // Skills
  const [skills, setSkills] = useState<Skill[]>([
    { id: '1', name: 'web_search', displayName: 'Web Search', description: 'Search the web for real-time information', category: 'research', icon: 'Search', isEnabled: true, isPublic: true, downloads: 15420, rating: 4.8, successRate: 98.5, price: 0, version: '2.1.0' },
    { id: '2', name: 'code_execution', displayName: 'Code Execution', description: 'Execute code in a sandboxed environment', category: 'development', icon: 'Code', isEnabled: true, isPublic: true, downloads: 12350, rating: 4.9, successRate: 99.2, price: 0, version: '3.0.1' },
    { id: '3', name: 'email_assistant', displayName: 'Email Assistant', description: 'Read, compose, and manage emails', category: 'productivity', icon: 'Mail', isEnabled: true, isPublic: true, downloads: 8920, rating: 4.7, successRate: 97.8, price: 0, version: '1.5.0' },
    { id: '4', name: 'data_analysis', displayName: 'Data Analysis', description: 'Analyze and visualize data', category: 'data', icon: 'BarChart3', isEnabled: false, isPublic: true, downloads: 7650, rating: 4.6, successRate: 96.5, price: 0, version: '2.0.0' },
    { id: '5', name: 'calendar', displayName: 'Calendar Manager', description: 'Manage events and reminders', category: 'productivity', icon: 'Calendar', isEnabled: false, isPublic: true, downloads: 9100, rating: 4.5, successRate: 98.0, price: 0, version: '1.8.0' },
    { id: '6', name: 'file_manager', displayName: 'File Manager', description: 'Read, write, and organize files', category: 'productivity', icon: 'FileText', isEnabled: true, isPublic: true, downloads: 11200, rating: 4.8, successRate: 99.0, price: 0, version: '2.2.0' },
  ]);
  
  // Memory
  const [memories, setMemories] = useState<Memory[]>([
    { id: '1', type: 'working', category: 'preference', content: 'User prefers concise responses with code examples', importance: 0.95, confidence: 0.98, accessCount: 45, createdAt: new Date() },
    { id: '2', type: 'semantic', category: 'fact', content: 'User is a software engineer working with TypeScript and React', importance: 0.88, confidence: 0.95, accessCount: 32, createdAt: new Date() },
    { id: '3', type: 'episodic', category: 'experience', content: 'Helped debug a WebSocket connection issue on March 25', importance: 0.72, confidence: 1.0, accessCount: 5, createdAt: new Date() },
    { id: '4', type: 'semantic', category: 'preference', content: 'User prefers dark mode interfaces with emerald accents', importance: 0.85, confidence: 0.92, accessCount: 28, createdAt: new Date() },
    { id: '5', type: 'procedural', category: 'workflow', content: 'Standard workflow: analyze problem → propose solutions → implement → verify', importance: 0.90, confidence: 0.97, accessCount: 67, createdAt: new Date() },
  ]);
  
  // Platforms
  const [platforms, setPlatforms] = useState<Platform[]>([
    { id: '1', name: 'WhatsApp', icon: platformIcons.whatsapp, isConnected: true, messagesCount: 234 },
    { id: '2', name: 'Telegram', icon: platformIcons.telegram, isConnected: true, messagesCount: 156 },
    { id: '3', name: 'Discord', icon: platformIcons.discord, isConnected: false, messagesCount: 0 },
    { id: '4', name: 'Slack', icon: platformIcons.slack, isConnected: false, messagesCount: 0 },
    { id: '5', name: 'Email', icon: platformIcons.email, isConnected: true, messagesCount: 89 },
  ]);
  
  // Learning events
  const [learningEvents, setLearningEvents] = useState<LearningEvent[]>([
    { id: '1', type: 'skill_improvement', description: 'Improved web_search accuracy by 2.3%', impact: 0.85, timestamp: new Date() },
    { id: '2', type: 'pattern_learned', description: 'New conversation pattern recognized', impact: 0.72, timestamp: new Date() },
    { id: '3', type: 'feedback_integrated', description: 'User feedback integrated into response style', impact: 0.68, timestamp: new Date() },
  ]);
  
  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Connection check
  useEffect(() => {
    setConnected(true);
  }, []);
  
  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);
  
  // Send message
  const handleSendMessage = useCallback(async () => {
    if (!inputValue.trim() || isLoading) return;
    
    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: new Date(),
      tokenCount: Math.ceil(inputValue.length / 4),
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    
    // API call
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage.content,
          agentId: activeAgent?.id || 'default',
        }),
      });
      
      const data = await response.json();
      
      if (data.success && data.message) {
        setMessages(prev => [...prev, {
          id: data.message.id,
          role: 'assistant',
          content: data.message.content,
          timestamp: new Date(data.message.timestamp),
          tokenCount: data.message.tokenCount,
        }]);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  }, [inputValue, isLoading, connected, activeAgent]);
  
  // Create agent
  const handleCreateAgent = () => {
    const newAgent: Agent = {
      id: Date.now().toString(),
      name: `Agent ${agents.length + 1}`,
      status: 'idle',
      learningEnabled: true,
      autoImprove: true,
      createdAt: new Date().toISOString(),
      stats: { messagesCount: 0, skillsCount: 5, memoryItems: 0, successRate: 100, improvementScore: 0 },
    };
    setAgents(prev => [...prev, newAgent]);
    setActiveAgent(newAgent);
    setMessages([]);
  };
  
  // Key press handler
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // ============================================================================
  // RENDER
  // ============================================================================

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
      
      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:static inset-y-0 left-0 z-50 w-80 bg-slate-900/95 backdrop-blur-xl border-r border-slate-800/50 flex flex-col transition-transform duration-300 shadow-xl",
        sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Logo */}
        <div className="p-4 border-b border-slate-800/50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
                  <Bot className="h-5 w-5 text-white" />
                </div>
                <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-emerald-400 border-2 border-slate-900 animate-pulse" />
              </div>
              <div>
                <span className="font-bold text-lg bg-gradient-to-r from-emerald-400 to-teal-400 bg-clip-text text-transparent">NeuralAgent</span>
                <p className="text-xs text-slate-500">Self-Improving AI Platform</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(false)}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        {/* New Agent Button */}
        <div className="p-4">
          <Button className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-lg shadow-emerald-500/20" onClick={handleCreateAgent}>
            <Plus className="h-4 w-4 mr-2" />
            Create New Agent
          </Button>
        </div>
        
        {/* Agents List */}
        <ScrollArea className="flex-1 px-3">
          <div className="space-y-2">
            <div className="text-xs font-medium text-slate-500 uppercase tracking-wider px-2 mb-2">Your Agents</div>
            {agents.map((agent) => (
              <button
                key={agent.id}
                onClick={() => { setActiveAgent(agent); setSidebarOpen(false); }}
                className={cn(
                  "w-full text-left p-3 rounded-xl transition-all duration-200",
                  activeAgent?.id === agent.id
                    ? "bg-gradient-to-r from-emerald-600/20 to-teal-600/20 border border-emerald-500/30"
                    : "hover:bg-slate-800/50 border border-transparent"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className={cn(
                    "w-10 h-10 rounded-xl flex items-center justify-center",
                    activeAgent?.id === agent.id ? "bg-emerald-500/20" : "bg-slate-800"
                  )}>
                    <Bot className={cn("h-5 w-5", activeAgent?.id === agent.id ? "text-emerald-400" : "text-slate-400")} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-medium truncate">{agent.name}</span>
                      <span className={cn(
                        "w-2 h-2 rounded-full",
                        agent.status === 'running' ? "bg-emerald-500 animate-pulse" :
                        agent.status === 'error' ? "bg-red-500" :
                        agent.status === 'paused' ? "bg-yellow-500" : "bg-slate-500"
                      )} />
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <span>{agent.stats.messagesCount} msgs</span>
                      <span>•</span>
                      <span>{agent.stats.successRate}% success</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </ScrollArea>
        
        {/* Platform Connections */}
        <div className="p-4 border-t border-slate-800/50">
          <div className="text-xs font-medium text-slate-500 uppercase tracking-wider mb-3">Platforms</div>
          <div className="grid grid-cols-5 gap-2">
            {platforms.map((platform) => (
              <button
                key={platform.id}
                className={cn(
                  "w-full aspect-square rounded-lg flex items-center justify-center transition-all",
                  platform.isConnected 
                    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30" 
                    : "bg-slate-800/50 text-slate-500 hover:bg-slate-800"
                )}
              >
                {platform.icon}
              </button>
            ))}
          </div>
        </div>
        
        {/* Security Badge */}
        <div className="p-4 border-t border-slate-800/50">
          <div className="flex items-center justify-between p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-emerald-400" />
              <span className="text-sm text-emerald-400">Security First</span>
            </div>
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              98%
            </Badge>
          </div>
        </div>
      </aside>
      
      {/* Main Content */}
      <main className="flex flex-col lg:flex-row min-h-screen">
        {/* Chat Area */}
        <div className="flex-1 flex flex-col min-h-screen">
          {/* Header */}
          <header className="border-b border-slate-800/50 bg-slate-900/50 backdrop-blur-xl sticky top-0 z-30">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="lg:hidden"
                  onClick={() => setSidebarOpen(true)}
                >
                  <Menu className="h-5 w-5" />
                </Button>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center">
                    <Bot className="h-5 w-5 text-emerald-400" />
                  </div>
                  <div>
                    <h1 className="font-semibold">{activeAgent?.name || 'Select an Agent'}</h1>
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Activity className="h-3 w-3" />
                      <span>{connected ? 'Connected' : 'Connecting...'}</span>
                      {activeAgent?.learningEnabled && (
                        <>
                          <span>•</span>
                          <Sparkles className="h-3 w-3 text-yellow-500" />
                          <span className="text-yellow-500">Learning</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                {/* Learning Score */}
                {activeAgent && (
                  <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/20">
                    <TrendingUp className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm text-yellow-500">+{activeAgent.stats.improvementScore}% improved</span>
                  </div>
                )}
                
                {/* Analytics Button */}
                <Button variant="outline" size="icon" onClick={() => setShowAnalytics(!showAnalytics)} className="border-slate-700">
                  <BarChart3 className="h-4 w-4" />
                </Button>
                
                {/* Marketplace Button */}
                <Button variant="outline" size="icon" onClick={() => setShowMarketplace(!showMarketplace)} className="border-slate-700">
                  <ShoppingBag className="h-4 w-4" />
                </Button>
                
                {/* Settings Button */}
                <Button variant="outline" size="icon" onClick={() => setShowSettings(!showSettings)} className="border-slate-700">
                  <Settings className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </header>
          
          {/* Analytics Panel (Collapsible) */}
          {showAnalytics && (
            <div className="border-b border-slate-800/50 bg-slate-900/30 backdrop-blur-xl p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card className="bg-slate-800/50 border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500">Total Messages</p>
                        <p className="text-2xl font-bold">{activeAgent?.stats.messagesCount.toLocaleString()}</p>
                      </div>
                      <MessageSquare className="h-8 w-8 text-blue-400" />
                    </div>
                    <div className="mt-2 flex items-center gap-1 text-xs text-emerald-400">
                      <ArrowUpRight className="h-3 w-3" />
                      <span>+12% this week</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-slate-800/50 border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500">Success Rate</p>
                        <p className="text-2xl font-bold">{activeAgent?.stats.successRate}%</p>
                      </div>
                      <Target className="h-8 w-8 text-emerald-400" />
                    </div>
                    <div className="mt-2 flex items-center gap-1 text-xs text-emerald-400">
                      <ArrowUpRight className="h-3 w-3" />
                      <span>+2.3% improved</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-slate-800/50 border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500">Memory Items</p>
                        <p className="text-2xl font-bold">{activeAgent?.stats.memoryItems}</p>
                      </div>
                      <Brain className="h-8 w-8 text-purple-400" />
                    </div>
                    <div className="mt-2 flex items-center gap-1 text-xs text-emerald-400">
                      <ArrowUpRight className="h-3 w-3" />
                      <span>+45 this week</span>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="bg-slate-800/50 border-slate-700/50">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-xs text-slate-500">Active Skills</p>
                        <p className="text-2xl font-bold">{activeAgent?.stats.skillsCount}</p>
                      </div>
                      <Zap className="h-8 w-8 text-yellow-400" />
                    </div>
                    <div className="mt-2 flex items-center gap-1 text-xs text-slate-400">
                      <Minus className="h-3 w-3" />
                      <span>No change</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
          
          {/* Messages Area */}
          <ScrollArea className="flex-1 p-4">
            {messages.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center h-full min-h-[60vh] text-center p-8">
                <div className="relative">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-2xl shadow-emerald-500/30">
                    <Sparkles className="h-10 w-10 text-white" />
                  </div>
                  <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-yellow-500 flex items-center justify-center">
                    <TrendingUp className="h-4 w-4 text-white" />
                  </div>
                </div>
                <h2 className="text-2xl font-bold mt-6 mb-2">Welcome to NeuralAgent</h2>
                <p className="text-slate-400 max-w-md mb-8">
                  The revolutionary AI platform combining multi-platform messaging with self-improving learning capabilities. 
                  Start a conversation to experience the future of AI assistance.
                </p>
                
                {/* Feature Cards */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-2xl">
                  <Card className="bg-slate-800/50 border-slate-700/50 hover:border-emerald-500/30 transition-colors">
                    <CardContent className="p-4 text-center">
                      <div className="w-12 h-12 rounded-xl bg-emerald-500/20 flex items-center justify-center mx-auto mb-3">
                        <Brain className="h-6 w-6 text-emerald-400" />
                      </div>
                      <h3 className="font-semibold mb-1">Self-Improving</h3>
                      <p className="text-xs text-slate-500">Learns and improves from every interaction</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-slate-800/50 border-slate-700/50 hover:border-purple-500/30 transition-colors">
                    <CardContent className="p-4 text-center">
                      <div className="w-12 h-12 rounded-xl bg-purple-500/20 flex items-center justify-center mx-auto mb-3">
                        <Layers className="h-6 w-6 text-purple-400" />
                      </div>
                      <h3 className="font-semibold mb-1">Multi-Platform</h3>
                      <p className="text-xs text-slate-500">Connect WhatsApp, Telegram, Discord & more</p>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-slate-800/50 border-slate-700/50 hover:border-yellow-500/30 transition-colors">
                    <CardContent className="p-4 text-center">
                      <div className="w-12 h-12 rounded-xl bg-yellow-500/20 flex items-center justify-center mx-auto mb-3">
                        <Zap className="h-6 w-6 text-yellow-400" />
                      </div>
                      <h3 className="font-semibold mb-1">Skill Marketplace</h3>
                      <p className="text-xs text-slate-500">Extend capabilities with community skills</p>
                    </CardContent>
                  </Card>
                </div>
              </div>
            ) : (
              <div className="space-y-4 max-w-3xl mx-auto">
                {messages.map((message) => (
                  <div key={message.id} className={cn(
                    "flex gap-3",
                    message.role === 'user' ? "flex-row-reverse" : ""
                  )}>
                    <div className={cn(
                      "flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center",
                      message.role === 'user' ? "bg-slate-700" : "bg-gradient-to-br from-emerald-500 to-teal-600"
                    )}>
                      {message.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                    </div>
                    
                    <div className={cn(
                      "flex-1 max-w-[80%]",
                      message.role === 'user' ? "text-right" : ""
                    )}>
                      <div className={cn(
                        "inline-block px-4 py-3 rounded-2xl text-sm",
                        message.role === 'user' 
                          ? "bg-emerald-600 text-white rounded-br-sm" 
                          : "bg-slate-800/80 text-slate-200 rounded-bl-sm border border-slate-700/50"
                      )}>
                        {message.content}
                      </div>
                      
                      <div className={cn(
                        "flex items-center gap-2 text-xs text-slate-500 mt-1",
                        message.role === 'user' ? "justify-end" : ""
                      )}>
                        <Clock className="h-3 w-3" />
                        <span>{new Date(message.timestamp).toLocaleTimeString()}</span>
                        {message.tokenCount && (
                          <Badge variant="outline" className="text-[10px] h-4 border-slate-700">
                            {message.tokenCount} tokens
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex gap-3">
                    <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
                      <Bot className="h-4 w-4" />
                    </div>
                    <div className="bg-slate-800/80 rounded-2xl rounded-bl-sm px-4 py-3 border border-slate-700/50">
                      <div className="flex items-center gap-2 text-slate-400">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        <span>Thinking...</span>
                      </div>
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>
            )}
          </ScrollArea>
          
          {/* Input Area */}
          <div className="border-t border-slate-800/50 bg-slate-900/50 backdrop-blur-xl p-4">
            <div className="max-w-3xl mx-auto">
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <Input
                    ref={inputRef}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyPress}
                    placeholder="Type your message..."
                    className="w-full bg-slate-800/50 border-slate-700 focus:border-emerald-500 focus:ring-emerald-500/20 pr-10"
                    disabled={isLoading}
                  />
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                    <Button variant="ghost" size="icon" className="h-7 w-7 text-slate-500 hover:text-slate-300">
                      <Paperclip className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                <Button 
                  onClick={handleSendMessage} 
                  disabled={!inputValue.trim() || isLoading}
                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
              <div className="mt-2 flex items-center justify-center gap-4 text-xs text-slate-600">
                <span className="flex items-center gap-1"><Cpu className="h-3 w-3" /> GPT-4o</span>
                <span>•</span>
                <span className="flex items-center gap-1"><Brain className="h-3 w-3" /> Persistent Memory</span>
                <span>•</span>
                <span className="flex items-center gap-1"><Shield className="h-3 w-3" /> Secure Execution</span>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Panel */}
        {rightPanelOpen && (
          <div className="hidden lg:block w-96 border-l border-slate-800/50 bg-slate-900/30 backdrop-blur-xl overflow-hidden">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
              <TabsList className="w-full justify-start bg-transparent border-b border-slate-800/50 rounded-none p-0 h-auto">
                <TabsTrigger 
                  value="skills" 
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-emerald-500 rounded-none py-3 px-4"
                >
                  <Zap className="h-4 w-4 mr-2" />
                  Skills
                </TabsTrigger>
                <TabsTrigger 
                  value="memory"
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-emerald-500 rounded-none py-3 px-4"
                >
                  <Brain className="h-4 w-4 mr-2" />
                  Memory
                </TabsTrigger>
                <TabsTrigger 
                  value="learning"
                  className="data-[state=active]:bg-transparent data-[state=active]:border-b-2 data-[state=active]:border-emerald-500 rounded-none py-3 px-4"
                >
                  <TrendingUp className="h-4 w-4 mr-2" />
                  Learning
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="skills" className="flex-1 overflow-auto p-4 m-0">
                <div className="space-y-3">
                  {skills.map((skill) => (
                    <div 
                      key={skill.id}
                      className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/50 hover:border-emerald-500/30 transition-all"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-10 h-10 rounded-lg flex items-center justify-center",
                            skill.isEnabled ? "bg-emerald-500/20" : "bg-slate-700"
                          )}>
                            {skill.icon === 'Search' && <Search className={cn("h-5 w-5", skill.isEnabled ? "text-emerald-400" : "text-slate-500")} />}
                            {skill.icon === 'Code' && <Code className={cn("h-5 w-5", skill.isEnabled ? "text-emerald-400" : "text-slate-500")} />}
                            {skill.icon === 'Mail' && <Mail className={cn("h-5 w-5", skill.isEnabled ? "text-emerald-400" : "text-slate-500")} />}
                            {skill.icon === 'BarChart3' && <BarChart3 className={cn("h-5 w-5", skill.isEnabled ? "text-emerald-400" : "text-slate-500")} />}
                            {skill.icon === 'Calendar' && <Calendar className={cn("h-5 w-5", skill.isEnabled ? "text-emerald-400" : "text-slate-500")} />}
                            {skill.icon === 'FileText' && <FileText className={cn("h-5 w-5", skill.isEnabled ? "text-emerald-400" : "text-slate-500")} />}
                          </div>
                          <div>
                            <h4 className="font-medium">{skill.displayName}</h4>
                            <p className="text-xs text-slate-500">{skill.description}</p>
                          </div>
                        </div>
                        <Switch checked={skill.isEnabled} />
                      </div>
                      
                      <div className="flex items-center gap-4 text-xs text-slate-500 mt-3 pt-3 border-t border-slate-700/50">
                        <span className="flex items-center gap-1">
                          <Star className="h-3 w-3 text-yellow-500" />
                          {skill.rating}
                        </span>
                        <span className="flex items-center gap-1">
                          <Download className="h-3 w-3" />
                          {skill.downloads.toLocaleString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="h-3 w-3 text-emerald-500" />
                          {skill.successRate}%
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="memory" className="flex-1 overflow-auto p-4 m-0">
                <div className="space-y-3">
                  {memories.map((memory) => (
                    <div 
                      key={memory.id}
                      className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/50"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <Badge className={cn(
                          memory.type === 'working' && "bg-blue-500/20 text-blue-400 border-blue-500/30",
                          memory.type === 'episodic' && "bg-purple-500/20 text-purple-400 border-purple-500/30",
                          memory.type === 'semantic' && "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
                          memory.type === 'procedural' && "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                        )}>
                          {memory.type}
                        </Badge>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-slate-500">{Math.round(memory.importance * 100)}%</span>
                          <div className="w-16 h-1.5 bg-slate-700 rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-emerald-500 rounded-full"
                              style={{ width: `${memory.importance * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-slate-300">{memory.content}</p>
                      <div className="flex items-center gap-3 text-xs text-slate-500 mt-2 pt-2 border-t border-slate-700/50">
                        <span className="flex items-center gap-1">
                          <Eye className="h-3 w-3" />
                          {memory.accessCount} accesses
                        </span>
                        <span className="flex items-center gap-1">
                          <Target className="h-3 w-3" />
                          {Math.round(memory.confidence * 100)}% confidence
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </TabsContent>
              
              <TabsContent value="learning" className="flex-1 overflow-auto p-4 m-0">
                <div className="space-y-4">
                  {/* Learning Stats */}
                  <Card className="bg-gradient-to-br from-yellow-500/10 to-orange-500/10 border-yellow-500/20">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-medium">Self-Improvement Score</h4>
                        <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                          Active
                        </Badge>
                      </div>
                      <div className="text-3xl font-bold text-yellow-400 mb-2">
                        +{activeAgent?.stats.improvementScore || 0}%
                      </div>
                      <p className="text-xs text-slate-500">Cumulative improvement since creation</p>
                    </CardContent>
                  </Card>
                  
                  {/* Learning Events */}
                  <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Recent Learning Events</div>
                  <div className="space-y-2">
                    {learningEvents.map((event) => (
                      <div 
                        key={event.id}
                        className="p-3 rounded-lg bg-slate-800/30 border border-slate-700/50"
                      >
                        <div className="flex items-center gap-2">
                          <div className={cn(
                            "w-8 h-8 rounded-lg flex items-center justify-center",
                            event.type === 'skill_improvement' && "bg-emerald-500/20",
                            event.type === 'pattern_learned' && "bg-purple-500/20",
                            event.type === 'feedback_integrated' && "bg-blue-500/20"
                          )}>
                            {event.type === 'skill_improvement' && <TrendingUp className="h-4 w-4 text-emerald-400" />}
                            {event.type === 'pattern_learned' && <Lightbulb className="h-4 w-4 text-purple-400" />}
                            {event.type === 'feedback_integrated' && <ThumbsUp className="h-4 w-4 text-blue-400" />}
                          </div>
                          <div className="flex-1">
                            <p className="text-sm">{event.description}</p>
                            <p className="text-xs text-slate-500">
                              {new Date(event.timestamp).toLocaleTimeString()}
                            </p>
                          </div>
                          <Badge variant="outline" className="border-emerald-500/30 text-emerald-400">
                            +{Math.round(event.impact * 100)}%
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </main>
      
      {/* Settings Dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent className="max-w-2xl bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle>Settings</DialogTitle>
            <DialogDescription>Configure your AI agent platform</DialogDescription>
          </DialogHeader>
          
          <Tabs value={activeSettingsTab} onValueChange={setActiveSettingsTab}>
            <TabsList className="bg-slate-800">
              <TabsTrigger value="general">General</TabsTrigger>
              <TabsTrigger value="learning">Learning</TabsTrigger>
              <TabsTrigger value="platforms">Platforms</TabsTrigger>
              <TabsTrigger value="security">Security</TabsTrigger>
            </TabsList>
            
            <TabsContent value="general" className="space-y-4 mt-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Dark Mode</Label>
                    <p className="text-sm text-slate-500">Enable dark mode interface</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Notifications</Label>
                    <p className="text-sm text-slate-500">Receive notifications for new messages</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                
                <div className="space-y-2">
                  <Label>Default Model</Label>
                  <select className="w-full bg-slate-800 border border-slate-700 rounded-md p-2">
                    <option>GPT-4o (Recommended)</option>
                    <option>GPT-4 Turbo</option>
                    <option>Claude 3.5 Sonnet</option>
                    <option>Claude 3 Opus</option>
                  </select>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="learning" className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Enable Learning</Label>
                  <p className="text-sm text-slate-500">Allow agent to learn from interactions</p>
                </div>
                <Switch checked={activeAgent?.learningEnabled} />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-Improve Skills</Label>
                  <p className="text-sm text-slate-500">Automatically optimize skill performance</p>
                </div>
                <Switch checked={activeAgent?.autoImprove} />
              </div>
              
              <div className="space-y-2">
                <Label>Learning Intensity</Label>
                <Slider defaultValue={[50]} max={100} step={10} />
                <p className="text-xs text-slate-500">Higher values mean more aggressive learning</p>
              </div>
            </TabsContent>
            
            <TabsContent value="platforms" className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                {platforms.map((platform) => (
                  <div 
                    key={platform.id}
                    className="p-4 rounded-lg bg-slate-800/50 border border-slate-700 flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      {platform.icon}
                      <span>{platform.name}</span>
                    </div>
                    <Button 
                      variant={platform.isConnected ? "destructive" : "default"}
                      size="sm"
                    >
                      {platform.isConnected ? 'Disconnect' : 'Connect'}
                    </Button>
                  </div>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="security" className="space-y-4 mt-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Two-Factor Authentication</Label>
                  <p className="text-sm text-slate-500">Add extra security to your account</p>
                </div>
                <Switch />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Prompt Injection Protection</Label>
                  <p className="text-sm text-slate-500">Detect and block malicious prompts</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <Label>Data Encryption</Label>
                  <p className="text-sm text-slate-500">Encrypt sensitive data at rest</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="h-4 w-4 text-emerald-400" />
                  <span className="font-medium text-emerald-400">Security Score: 98%</span>
                </div>
                <p className="text-xs text-slate-500">Your account has excellent security settings</p>
              </div>
            </TabsContent>
          </Tabs>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSettings(false)}>Cancel</Button>
            <Button onClick={() => setShowSettings(false)}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Marketplace Dialog */}
      <Dialog open={showMarketplace} onOpenChange={setShowMarketplace}>
        <DialogContent className="max-w-4xl bg-slate-900 border-slate-800">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              Skill Marketplace
            </DialogTitle>
            <DialogDescription>Browse and install community skills</DialogDescription>
          </DialogHeader>
          
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
            <Input placeholder="Search skills..." className="pl-10 bg-slate-800 border-slate-700" />
          </div>
          
          <div className="grid grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto">
            {skills.concat([
              { id: '7', name: 'image_gen', displayName: 'Image Generation', description: 'Generate images from text descriptions', category: 'creative', icon: 'Image', isEnabled: false, isPublic: true, downloads: 23450, rating: 4.9, successRate: 97.5, price: 0, version: '1.0.0' },
              { id: '8', name: 'music_gen', displayName: 'Music Generation', description: 'Create music from text prompts', category: 'creative', icon: 'Music', isEnabled: false, isPublic: true, downloads: 18200, rating: 4.7, successRate: 95.8, price: 9.99, version: '1.0.0' },
              { id: '9', name: 'video_edit', displayName: 'Video Editor', description: 'Edit and process videos', category: 'media', icon: 'Video', isEnabled: false, isPublic: true, downloads: 12500, rating: 4.6, successRate: 94.2, price: 0, version: '1.0.0' },
              { id: '10', name: 'map_navigator', displayName: 'Map Navigator', description: 'Navigate and explore maps', category: 'travel', icon: 'Map', isEnabled: false, isPublic: true, downloads: 8900, rating: 4.5, successRate: 96.8, price: 0, version: '1.0.0' },
            ]).map((skill) => (
              <div 
                key={skill.id}
                className="p-4 rounded-xl bg-slate-800/30 border border-slate-700/50 hover:border-emerald-500/30 transition-all"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center">
                      {skill.icon === 'Image' && <ImageIcon className="h-6 w-6 text-emerald-400" alt="Image Generation" />}
                      {skill.icon === 'Music' && <Music className="h-6 w-6 text-emerald-400" />}
                      {skill.icon === 'Video' && <Video className="h-6 w-6 text-emerald-400" />}
                      {skill.icon === 'Map' && <Map className="h-6 w-6 text-emerald-400" />}
                      {!['Image', 'Music', 'Video', 'Map'].includes(skill.icon) && <Zap className="h-6 w-6 text-emerald-400" />}
                    </div>
                    <div>
                      <h4 className="font-medium">{skill.displayName}</h4>
                      <p className="text-xs text-slate-500">{skill.category}</p>
                    </div>
                  </div>
                  {skill.price > 0 && (
                    <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                      ${skill.price}
                    </Badge>
                  )}
                </div>
                
                <p className="text-sm text-slate-400 mb-3">{skill.description}</p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <Star className="h-3 w-3 text-yellow-500" />
                      {skill.rating}
                    </span>
                    <span className="flex items-center gap-1">
                      <Download className="h-3 w-3" />
                      {skill.downloads.toLocaleString()}
                    </span>
                  </div>
                  <Button size="sm" variant="outline" className="border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/10">
                    {skill.isEnabled ? 'Installed' : 'Install'}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Missing icon component
function Paperclip(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m13.234 19.264 6.264-6.264a3 3 0 0 0 0-4.244l-4.244-4.244a3 3 0 0 0-4.244 0L4.746 9.106a3 3 0 0 0 0 4.244l6.264 6.264" />
      <path d="m8.106 14.765 3.889-3.889" />
      <path d="m17.121 5.879-3.889 3.889" />
    </svg>
  );
}
