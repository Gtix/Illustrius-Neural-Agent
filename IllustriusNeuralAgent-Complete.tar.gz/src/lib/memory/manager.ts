/**
 * Memory System Module
 * 
 * Implements a hierarchical memory architecture inspired by human cognition:
 * 
 * 1. Working Memory - Short-term, high-priority, session-based
 * 2. Episodic Memory - Event-based, time-stamped experiences
 * 3. Semantic Memory - Facts, knowledge, learned concepts
 * 
 * Features:
 * - Hybrid retrieval (keyword + vector similarity)
 * - Memory importance scoring
 * - Automatic compaction and archival
 * - Cross-session persistence
 * - Memory decay based on access patterns
 */

import { db } from '../db';
import { Memory, MemoryType, MemoryInterface, SearchResult } from '../types';

// ============================================================================
// CONFIGURATION
// ============================================================================

const MEMORY_CONFIG = {
  workingMemory: {
    maxSize: 50, // Maximum items in working memory
    defaultImportance: 0.8,
    decayRate: 0.1, // Importance reduction per day
  },
  episodicMemory: {
    retentionDays: 90,
    maxItems: 1000,
  },
  semanticMemory: {
    embeddingDimensions: 1536, // OpenAI embedding size
    similarityThreshold: 0.75,
  },
  importanceThreshold: 0.3, // Below this, memory is archived
};

// ============================================================================
// MEMORY IMPORTANCE CALCULATOR
// ============================================================================

interface ImportanceFactors {
  recency: number;      // 0-1, how recent is this memory
  accessCount: number;  // Normalized access frequency
  type: MemoryType;     // Memory type weight
  explicit?: boolean;   // User explicitly saved this
  emotional?: boolean;  // Contains emotionally significant content
}

/**
 * Calculate memory importance score
 */
function calculateImportance(factors: ImportanceFactors): number {
  const weights = {
    recency: 0.3,
    accessCount: 0.25,
    type: 0.2,
    explicit: 0.15,
    emotional: 0.1,
  };
  
  const typeWeights: Record<MemoryType, number> = {
    working: 0.9,
    episodic: 0.7,
    semantic: 0.8,
  };
  
  let score = 0;
  
  // Recency component (exponential decay)
  score += factors.recency * weights.recency;
  
  // Access count component (logarithmic scaling)
  const normalizedAccess = Math.min(1, Math.log10(factors.accessCount + 1) / 2);
  score += normalizedAccess * weights.accessCount;
  
  // Type component
  score += typeWeights[factors.type] * weights.type;
  
  // Explicit save bonus
  if (factors.explicit) {
    score += weights.explicit;
  }
  
  // Emotional significance bonus
  if (factors.emotional) {
    score += weights.emotional;
  }
  
  return Math.min(1, Math.max(0, score));
}

// ============================================================================
// SIMPLE VECTOR OPERATIONS
// ============================================================================

/**
 * Cosine similarity between two vectors
 */
function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0;
  
  let dotProduct = 0;
  let normA = 0;
  let normB = 0;
  
  for (let i = 0; i < a.length; i++) {
    dotProduct += a[i] * b[i];
    normA += a[i] * a[i];
    normB += b[i] * b[i];
  }
  
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
}

/**
 * Generate a simple embedding (placeholder - in production use actual embeddings)
 */
function generateSimpleEmbedding(text: string): number[] {
  // This is a simplified embedding using character frequencies
  // In production, use OpenAI embeddings or similar
  const dimensions = MEMORY_CONFIG.semanticMemory.embeddingDimensions;
  const embedding: number[] = new Array(dimensions).fill(0);
  
  const normalized = text.toLowerCase().replace(/[^a-z0-9\s]/g, '');
  const words = normalized.split(/\s+/);
  
  for (const word of words) {
    for (let i = 0; i < word.length; i++) {
      const charCode = word.charCodeAt(i);
      const index = (charCode * (i + 1)) % dimensions;
      embedding[index] += 1 / (i + 1);
    }
  }
  
  // Normalize
  const norm = Math.sqrt(embedding.reduce((sum, val) => sum + val * val, 0));
  if (norm > 0) {
    for (let i = 0; i < embedding.length; i++) {
      embedding[i] /= norm;
    }
  }
  
  return embedding;
}

// ============================================================================
// MEMORY MANAGER
// ============================================================================

/**
 * Main memory management class
 */
export class MemoryManager implements MemoryInterface {
  private agentId: string;
  private workingMemory: Memory[] = [];
  
  constructor(agentId: string) {
    this.agentId = agentId;
  }
  
  /**
   * Add a new memory
   */
  async add(
    content: string,
    type: MemoryType,
    metadata: Record<string, unknown> = {}
  ): Promise<Memory> {
    // Generate embedding for semantic search
    const embedding = type === 'semantic' ? generateSimpleEmbedding(content) : undefined;
    
    // Calculate initial importance
    const importance = calculateImportance({
      recency: 1,
      accessCount: 0,
      type,
      explicit: metadata.explicit as boolean,
    });
    
    // Create memory record
    const memory = await db.memory.create({
      data: {
        agentId: this.agentId,
        type,
        category: metadata.category as string,
        content,
        embedding: embedding ? JSON.stringify(embedding) : undefined,
        importance,
        accessCount: 0,
        metadata: JSON.stringify(metadata),
      },
    });
    
    // Update working memory
    if (type === 'working') {
      this.workingMemory.push(memory as unknown as Memory);
      await this.trimWorkingMemory();
    }
    
    return memory as unknown as Memory;
  }
  
  /**
   * Search memories by query
   */
  async search(query: string, limit: number = 10): Promise<Memory[]> {
    const queryEmbedding = generateSimpleEmbedding(query);
    const threshold = MEMORY_CONFIG.semanticMemory.similarityThreshold;
    
    // Get all memories for this agent
    const memories = await db.memory.findMany({
      where: {
        agentId: this.agentId,
        importance: { gte: MEMORY_CONFIG.importanceThreshold },
      },
      orderBy: [
        { importance: 'desc' },
        { createdAt: 'desc' },
      ],
      take: limit * 3, // Get more than needed for similarity filtering
    });
    
    // Calculate similarities
    const scoredMemories = memories.map(memory => {
      let similarity = 0;
      
      if (memory.embedding) {
        const embedding = JSON.parse(memory.embedding as string) as number[];
        similarity = cosineSimilarity(queryEmbedding, embedding);
      }
      
      // Keyword matching boost
      const keywordMatch = this.keywordMatch(query, memory.content);
      const combinedScore = similarity * 0.7 + keywordMatch * 0.3;
      
      return {
        memory,
        score: combinedScore,
        similarity,
        keywordMatch,
      };
    });
    
    // Sort by combined score
    scoredMemories.sort((a, b) => b.score - a.score);
    
    // Filter by threshold and take top results
    const results = scoredMemories
      .filter(sm => sm.score >= threshold || sm.keywordMatch > 0.3)
      .slice(0, limit)
      .map(sm => sm.memory);
    
    // Update access counts
    for (const memory of results) {
      await this.updateAccessCount(memory.id);
    }
    
    return results as unknown as Memory[];
  }
  
  /**
   * Get a specific memory by ID
   */
  async get(id: string): Promise<Memory | null> {
    const memory = await db.memory.findUnique({
      where: { id },
    });
    
    if (memory && memory.agentId === this.agentId) {
      await this.updateAccessCount(id);
      return memory as unknown as Memory;
    }
    
    return null;
  }
  
  /**
   * Update a memory
   */
  async update(id: string, data: Partial<Memory>): Promise<Memory> {
    const updateData: Record<string, unknown> = {};
    
    if (data.content !== undefined) {
      updateData.content = data.content;
      updateData.embedding = generateSimpleEmbedding(data.content);
    }
    
    if (data.importance !== undefined) {
      updateData.importance = data.importance;
    }
    
    if (data.metadata !== undefined) {
      updateData.metadata = JSON.stringify(data.metadata);
    }
    
    const memory = await db.memory.update({
      where: { id },
      data: updateData,
    });
    
    return memory as unknown as Memory;
  }
  
  /**
   * Delete a memory
   */
  async delete(id: string): Promise<void> {
    await db.memory.delete({
      where: { id },
    });
    
    // Remove from working memory if present
    this.workingMemory = this.workingMemory.filter(m => m.id !== id);
  }
  
  /**
   * Compress old or low-importance memories
   */
  async compress(): Promise<void> {
    const cutoffDate = new Date(
      Date.now() - MEMORY_CONFIG.episodicMemory.retentionDays * 24 * 60 * 60 * 1000
    );
    
    // Archive low-importance memories
    await db.memory.updateMany({
      where: {
        agentId: this.agentId,
        importance: { lt: MEMORY_CONFIG.importanceThreshold },
        type: 'episodic',
      },
      data: {
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days until deletion
      },
    });
    
    // Delete expired memories
    await db.memory.deleteMany({
      where: {
        agentId: this.agentId,
        expiresAt: { lt: new Date() },
      },
    });
    
    // Apply decay to importance scores
    const memories = await db.memory.findMany({
      where: {
        agentId: this.agentId,
        type: { not: 'semantic' },
      },
    });
    
    for (const memory of memories) {
      const daysSinceAccess = memory.lastAccessed
        ? (Date.now() - memory.lastAccessed.getTime()) / (24 * 60 * 60 * 1000)
        : 0;
      
      const decayedImportance = Math.max(
        0,
        (memory.importance as number) - daysSinceAccess * MEMORY_CONFIG.workingMemory.decayRate
      );
      
      await db.memory.update({
        where: { id: memory.id },
        data: { importance: decayedImportance },
      });
    }
  }
  
  /**
   * Get all working memories
   */
  async getWorkingMemory(): Promise<Memory[]> {
    if (this.workingMemory.length === 0) {
      const memories = await db.memory.findMany({
        where: {
          agentId: this.agentId,
          type: 'working',
          importance: { gte: MEMORY_CONFIG.importanceThreshold },
        },
        orderBy: { createdAt: 'desc' },
        take: MEMORY_CONFIG.workingMemory.maxSize,
      });
      
      this.workingMemory = memories as unknown as Memory[];
    }
    
    return this.workingMemory;
  }
  
  /**
   * Get memories by category
   */
  async getByCategory(category: string, limit: number = 10): Promise<Memory[]> {
    const memories = await db.memory.findMany({
      where: {
        agentId: this.agentId,
        category,
        importance: { gte: MEMORY_CONFIG.importanceThreshold },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    
    return memories as unknown as Memory[];
  }
  
  /**
   * Store an episodic memory (event/experience)
   */
  async storeEpisode(
    event: string,
    context: Record<string, unknown>,
    emotional: boolean = false
  ): Promise<Memory> {
    const content = JSON.stringify({ event, context, timestamp: new Date().toISOString() });
    
    return this.add(content, 'episodic', {
      category: 'experience',
      emotional,
    });
  }
  
  /**
   * Store a semantic memory (fact/knowledge)
   */
  async storeFact(
    fact: string,
    category: string,
    source?: string
  ): Promise<Memory> {
    return this.add(fact, 'semantic', {
      category,
      source,
      explicit: true,
    });
  }
  
  /**
   * Store user preference
   */
  async storePreference(
    key: string,
    value: unknown,
    confidence: number = 1.0
  ): Promise<Memory> {
    return this.add(JSON.stringify({ key, value }), 'semantic', {
      category: 'user_preference',
      confidence,
    });
  }
  
  /**
   * Get user preferences
   */
  async getPreferences(): Promise<Record<string, unknown>> {
    const preferences = await db.memory.findMany({
      where: {
        agentId: this.agentId,
        category: 'user_preference',
        type: 'semantic',
      },
    });
    
    const result: Record<string, unknown> = {};
    for (const pref of preferences) {
      try {
        const { key, value } = JSON.parse(pref.content);
        result[key] = value;
      } catch {
        // Skip invalid entries
      }
    }
    
    return result;
  }
  
  // Private helper methods
  
  private async trimWorkingMemory(): Promise<void> {
    if (this.workingMemory.length > MEMORY_CONFIG.workingMemory.maxSize) {
      // Sort by importance
      this.workingMemory.sort((a, b) => b.importance - a.importance);
      
      // Remove lowest importance items
      const toRemove = this.workingMemory.splice(
        MEMORY_CONFIG.workingMemory.maxSize
      );
      
      // Demote removed items to episodic
      for (const memory of toRemove) {
        await db.memory.update({
          where: { id: memory.id },
          data: { type: 'episodic' },
        });
      }
    }
  }
  
  private async updateAccessCount(id: string): Promise<void> {
    await db.memory.update({
      where: { id },
      data: {
        accessCount: { increment: 1 },
        lastAccessed: new Date(),
      },
    });
  }
  
  private keywordMatch(query: string, content: string): number {
    const queryWords = new Set(
      query.toLowerCase().split(/\s+/).filter(w => w.length > 2)
    );
    const contentWords = new Set(
      content.toLowerCase().split(/\s+/).filter(w => w.length > 2)
    );
    
    if (queryWords.size === 0) return 0;
    
    let matches = 0;
    for (const word of queryWords) {
      if (contentWords.has(word)) matches++;
    }
    
    return matches / queryWords.size;
  }
}

// ============================================================================
// CONTEXT BUILDER
// ============================================================================

/**
 * Build context from memories for LLM prompts
 */
export class ContextBuilder {
  private memoryManager: MemoryManager;
  
  constructor(memoryManager: MemoryManager) {
    this.memoryManager = memoryManager;
  }
  
  /**
   * Build a context string for the LLM
   */
  async buildContext(
    query: string,
    maxTokens: number = 2000
  ): Promise<string> {
    const sections: string[] = [];
    let tokenCount = 0;
    
    // Get user preferences
    const preferences = await this.memoryManager.getPreferences();
    if (Object.keys(preferences).length > 0) {
      const prefString = `User preferences: ${JSON.stringify(preferences)}`;
      sections.push(prefString);
      tokenCount += estimateTokens(prefString);
    }
    
    // Get working memory
    const workingMemory = await this.memoryManager.getWorkingMemory();
    if (workingMemory.length > 0) {
      const workingString = `Recent context:\n${workingMemory
        .map(m => `- ${m.content}`)
        .join('\n')}`;
      sections.push(workingString);
      tokenCount += estimateTokens(workingString);
    }
    
    // Search for relevant memories
    const relevantMemories = await this.memoryManager.search(query, 5);
    if (relevantMemories.length > 0) {
      const relevantString = `Related memories:\n${relevantMemories
        .map(m => `- ${m.content}`)
        .join('\n')}`;
      
      const relevantTokens = estimateTokens(relevantString);
      if (tokenCount + relevantTokens <= maxTokens) {
        sections.push(relevantString);
        tokenCount += relevantTokens;
      }
    }
    
    return sections.join('\n\n');
  }
}

// ============================================================================
// UTILITY EXPORTS
// ============================================================================

export { estimateTokens };

/**
 * Estimate tokens (simple implementation)
 */
function estimateTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

export default MemoryManager;
