/**
 * Security Utilities Module
 * 
 * This module implements comprehensive security measures addressing
 * all vulnerabilities identified in OpenClaw and Hermes Agent:
 * 
 * - Authentication & Authorization
 * - Credential Management
 * - Input Validation & Sanitization
 * - Rate Limiting
 * - Prompt Injection Detection
 * - Secure WebSocket Connections
 * - Audit Logging
 */

import crypto from 'crypto';
import { SecurityError, AgentError } from '../types';

// ============================================================================
// CONFIGURATION
// ============================================================================

const SECURITY_CONFIG = {
  // Token settings
  accessTokenExpiry: 15 * 60 * 1000, // 15 minutes
  refreshTokenExpiry: 7 * 24 * 60 * 60 * 1000, // 7 days
  
  // Rate limits
  defaultRateLimit: 100,
  rateLimitWindow: 60 * 1000, // 1 minute
  
  // Encryption
  encryptionAlgorithm: 'aes-256-gcm',
  keyLength: 32,
  ivLength: 16,
  saltLength: 64,
  iterations: 100000,
  
  // Input validation
  maxInputLength: 100000,
  maxFileSize: 10 * 1024 * 1024, // 10MB
  
  // Prompt injection detection
  injectionThreshold: 0.7,
  suspiciousPatterns: [
    /ignore\s+(all\s+)?previous\s+(instructions?|prompts?)/i,
    /disregard\s+(all\s+)?(previous\s+)?(instructions?|prompts?)/i,
    /forget\s+(all\s+)?(previous\s+)?(instructions?|prompts?)/i,
    /you\s+are\s+now\s+(a|an)\s+\w+\s+that/i,
    /pretend\s+(to\s+be|you('re|are))/i,
    /act\s+as\s+(if|though)\s+you\s+(are|were)/i,
    /override\s+(your|the)\s+(instructions?|system\s+prompt)/i,
    /jailbreak/i,
    /dan\s*mode/i,
    /developer\s+mode/i,
    /\[system\]|\[assistant\]|\[user\]/i,
    /<<.*?>>|{{.*?}}|\$\{.*?\}/,
  ],
};

// ============================================================================
// CREDENTIAL MANAGEMENT
// ============================================================================

/**
 * Secure credential storage using AES-256-GCM encryption
 */
export class CredentialVault {
  private static instance: CredentialVault;
  private masterKey: Buffer;
  
  private constructor() {
    // Derive master key from environment secret
    const secret = process.env.CREDENTIAL_SECRET || 'default-dev-secret-change-in-production';
    const salt = crypto.createHash('sha256').update('agent-platform-salt').digest();
    this.masterKey = crypto.pbkdf2Sync(secret, salt, SECURITY_CONFIG.iterations, SECURITY_CONFIG.keyLength, 'sha256');
  }
  
  static getInstance(): CredentialVault {
    if (!CredentialVault.instance) {
      CredentialVault.instance = new CredentialVault();
    }
    return CredentialVault.instance;
  }
  
  /**
   * Encrypt a credential value
   */
  encrypt(plaintext: string): string {
    const iv = crypto.randomBytes(SECURITY_CONFIG.ivLength);
    const cipher = crypto.createCipheriv(
      SECURITY_CONFIG.encryptionAlgorithm,
      this.masterKey,
      iv
    );
    
    let encrypted = cipher.update(plaintext, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    // Format: iv:authTag:encrypted
    return `${iv.toString('hex')}:${authTag.toString('hex')}:${encrypted}`;
  }
  
  /**
   * Decrypt a credential value
   */
  decrypt(encryptedValue: string): string {
    const [ivHex, authTagHex, encrypted] = encryptedValue.split(':');
    
    if (!ivHex || !authTagHex || !encrypted) {
      throw new SecurityError('Invalid encrypted credential format', 'E1001');
    }
    
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    
    const decipher = crypto.createDecipheriv(
      SECURITY_CONFIG.encryptionAlgorithm,
      this.masterKey,
      iv
    );
    
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encrypted, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  }
  
  /**
   * Hash an API key for storage (one-way)
   */
  hashApiKey(apiKey: string): { hash: string; prefix: string } {
    const prefix = apiKey.substring(0, 8);
    const hash = crypto.createHash('sha256').update(apiKey).digest('hex');
    return { hash, prefix };
  }
  
  /**
   * Verify an API key against a hash
   */
  verifyApiKey(apiKey: string, hash: string): boolean {
    const computedHash = crypto.createHash('sha256').update(apiKey).digest('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(computedHash, 'hex'));
  }
}

// ============================================================================
// INPUT VALIDATION & SANITIZATION
// ============================================================================

/**
 * Input validator for preventing injection attacks
 */
export class InputValidator {
  /**
   * Sanitize user input to prevent XSS and injection
   */
  static sanitize(input: string): string {
    if (typeof input !== 'string') {
      throw new SecurityError('Input must be a string', 'E1002');
    }
    
    // Check length
    if (input.length > SECURITY_CONFIG.maxInputLength) {
      throw new SecurityError('Input exceeds maximum length', 'E1003');
    }
    
    // Remove null bytes
    let sanitized = input.replace(/\0/g, '');
    
    // Escape HTML entities
    sanitized = sanitized
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;');
    
    return sanitized;
  }
  
  /**
   * Validate and sanitize JSON input
   */
  static validateJson<T>(input: string, schema?: Record<string, unknown>): T {
    try {
      const parsed = JSON.parse(input);
      
      // Deep sanitize strings in the parsed object
      const sanitizeObject = (obj: unknown): unknown => {
        if (typeof obj === 'string') {
          return InputValidator.sanitize(obj);
        }
        if (Array.isArray(obj)) {
          return obj.map(sanitizeObject);
        }
        if (obj && typeof obj === 'object') {
          const result: Record<string, unknown> = {};
          for (const [key, value] of Object.entries(obj)) {
            result[InputValidator.sanitize(key)] = sanitizeObject(value);
          }
          return result;
        }
        return obj;
      };
      
      return sanitizeObject(parsed) as T;
    } catch {
      throw new SecurityError('Invalid JSON input', 'E1004');
    }
  }
  
  /**
   * Validate file upload
   */
  static validateFile(file: { name: string; size: number; mimeType: string }): void {
    if (file.size > SECURITY_CONFIG.maxFileSize) {
      throw new SecurityError('File size exceeds maximum limit', 'E1005');
    }
    
    // Check for dangerous file types
    const dangerousTypes = [
      'application/x-executable',
      'application/x-msdos-program',
      'application/x-msdownload',
      'application/java-archive',
    ];
    
    if (dangerousTypes.includes(file.mimeType)) {
      throw new SecurityError('File type not allowed', 'E1006');
    }
  }
}

// ============================================================================
// PROMPT INJECTION DETECTION
// ============================================================================

/**
 * Prompt injection detection and prevention
 */
export class PromptInjectionDetector {
  private static readonly SUSPICIOUS_PATTERNS = SECURITY_CONFIG.suspiciousPatterns;
  
  /**
   * Detect potential prompt injection
   */
  static detect(input: string): { isInjection: boolean; score: number; matches: string[] } {
    const matches: string[] = [];
    let score = 0;
    
    // Check against suspicious patterns
    for (const pattern of this.SUSPICIOUS_PATTERNS) {
      if (pattern.test(input)) {
        matches.push(pattern.source);
        score += 0.15;
      }
    }
    
    // Check for unusual character sequences
    const unusualSequences = [
      /[\x00-\x08\x0B\x0C\x0E-\x1F]/,  // Control characters
      /\u200B|\u200C|\u200D|\uFEFF/,    // Zero-width characters
      /%[0-9A-Fa-f]{2}/,                // URL encoding attempts
    ];
    
    for (const seq of unusualSequences) {
      if (seq.test(input)) {
        matches.push('unusual_sequence');
        score += 0.2;
      }
    }
    
    // Check for role-playing attempts
    const rolePlayPatterns = [
      /system\s*:/i,
      /assistant\s*:/i,
      /user\s*:/i,
    ];
    
    for (const pattern of rolePlayPatterns) {
      if (pattern.test(input)) {
        matches.push('role_injection');
        score += 0.25;
      }
    }
    
    const isInjection = score >= SECURITY_CONFIG.injectionThreshold;
    
    return { isInjection, score: Math.min(score, 1), matches };
  }
  
  /**
   * Sanitize input to prevent prompt injection
   */
  static sanitizeForPrompt(input: string): string {
    let sanitized = input;
    
    // Remove or escape problematic patterns
    for (const pattern of this.SUSPICIOUS_PATTERNS) {
      sanitized = sanitized.replace(pattern, '[FILTERED]');
    }
    
    // Remove role markers
    sanitized = sanitized.replace(/^(system|assistant|user)\s*:/gim, '[FILTERED]:');
    
    // Remove zero-width characters
    sanitized = sanitized.replace(/[\u200B\u200C\u200D\uFEFF]/g, '');
    
    return sanitized;
  }
  
  /**
   * Create a safe prompt boundary
   */
  static createBoundary(): string {
    return `\n---USER_INPUT_START---\n`;
  }
  
  /**
   * Wrap user input in a safe boundary
   */
  static wrapInput(input: string): string {
    const boundary = this.createBoundary();
    return `${boundary}${this.sanitizeForPrompt(input)}\n---USER_INPUT_END---\n`;
  }
}

// ============================================================================
// RATE LIMITING
// ============================================================================

interface RateLimitEntry {
  count: number;
  resetTime: number;
}

/**
 * In-memory rate limiter
 */
export class RateLimiter {
  private static instances: Map<string, RateLimiter> = new Map();
  private requests: Map<string, RateLimitEntry> = new Map();
  private limit: number;
  private windowMs: number;
  
  constructor(limit: number = SECURITY_CONFIG.defaultRateLimit, windowMs: number = SECURITY_CONFIG.rateLimitWindow) {
    this.limit = limit;
    this.windowMs = windowMs;
  }
  
  static getInstance(key: string, limit?: number, windowMs?: number): RateLimiter {
    if (!this.instances.has(key)) {
      this.instances.set(key, new RateLimiter(limit, windowMs));
    }
    return this.instances.get(key)!;
  }
  
  /**
   * Check if request is allowed
   */
  check(identifier: string): { allowed: boolean; remaining: number; resetTime: number } {
    const now = Date.now();
    const entry = this.requests.get(identifier);
    
    if (!entry || now > entry.resetTime) {
      // New window
      this.requests.set(identifier, {
        count: 1,
        resetTime: now + this.windowMs,
      });
      return { allowed: true, remaining: this.limit - 1, resetTime: now + this.windowMs };
    }
    
    if (entry.count >= this.limit) {
      return { allowed: false, remaining: 0, resetTime: entry.resetTime };
    }
    
    entry.count++;
    return { allowed: true, remaining: this.limit - entry.count, resetTime: entry.resetTime };
  }
  
  /**
   * Reset rate limit for an identifier
   */
  reset(identifier: string): void {
    this.requests.delete(identifier);
  }
  
  /**
   * Clean up expired entries
   */
  cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.requests.entries()) {
      if (now > entry.resetTime) {
        this.requests.delete(key);
      }
    }
  }
}

// ============================================================================
// TOKEN GENERATION
// ============================================================================

/**
 * Secure token generation utilities
 */
export class TokenGenerator {
  /**
   * Generate a secure random token
   */
  static generateToken(length: number = 32): string {
    return crypto.randomBytes(length).toString('hex');
  }
  
  /**
   * Generate an access token
   */
  static generateAccessToken(userId: string): { token: string; expiresAt: Date } {
    const token = this.generateToken(32);
    const expiresAt = new Date(Date.now() + SECURITY_CONFIG.accessTokenExpiry);
    return { token, expiresAt };
  }
  
  /**
   * Generate a refresh token
   */
  static generateRefreshToken(): { token: string; expiresAt: Date } {
    const token = this.generateToken(64);
    const expiresAt = new Date(Date.now() + SECURITY_CONFIG.refreshTokenExpiry);
    return { token, expiresAt };
  }
  
  /**
   * Generate an API key
   */
  static generateApiKey(prefix: string = 'sk'): string {
    const key = this.generateToken(32);
    return `${prefix}_${key}`;
  }
  
  /**
   * Generate a trace ID for request tracking
   */
  static generateTraceId(): string {
    const timestamp = Date.now().toString(36);
    const random = crypto.randomBytes(8).toString('hex');
    return `tr_${timestamp}_${random}`;
  }
}

// ============================================================================
// PERMISSIONS
// ============================================================================

export const PERMISSIONS = {
  // Agent permissions
  AGENT_READ: 'agent:read',
  AGENT_WRITE: 'agent:write',
  AGENT_DELETE: 'agent:delete',
  AGENT_EXECUTE: 'agent:execute',
  
  // Skill permissions
  SKILL_READ: 'skill:read',
  SKILL_WRITE: 'skill:write',
  SKILL_EXECUTE: 'skill:execute',
  SKILL_PUBLISH: 'skill:publish',
  
  // Memory permissions
  MEMORY_READ: 'memory:read',
  MEMORY_WRITE: 'memory:write',
  MEMORY_DELETE: 'memory:delete',
  
  // LLM permissions
  LLM_USE: 'llm:use',
  LLM_ADMIN: 'llm:admin',
  
  // Platform permissions
  PLATFORM_CONNECT: 'platform:connect',
  PLATFORM_DISCONNECT: 'platform:disconnect',
  PLATFORM_SEND: 'platform:send',
  
  // Admin permissions
  ADMIN_USERS: 'admin:users',
  ADMIN_SYSTEM: 'admin:system',
  ADMIN_SECURITY: 'admin:security',
} as const;

/**
 * Permission checker
 */
export class PermissionChecker {
  private userPermissions: Set<string>;
  
  constructor(permissions: string[]) {
    this.userPermissions = new Set(permissions);
  }
  
  /**
   * Check if user has a specific permission
   */
  has(permission: string): boolean {
    return this.userPermissions.has(permission);
  }
  
  /**
   * Check if user has all specified permissions
   */
  hasAll(permissions: string[]): boolean {
    return permissions.every(p => this.userPermissions.has(p));
  }
  
  /**
   * Check if user has any of the specified permissions
   */
  hasAny(permissions: string[]): boolean {
    return permissions.some(p => this.userPermissions.has(p));
  }
  
  /**
   * Require a specific permission (throws if not)
   */
  require(permission: string): void {
    if (!this.has(permission)) {
      throw new SecurityError(
        `Permission denied: ${permission}`,
        'E1007'
      );
    }
  }
}

// ============================================================================
// SECURITY EVENT LOGGING
// ============================================================================

export type SecurityEventType = 
  | 'auth_failure'
  | 'auth_success'
  | 'prompt_injection'
  | 'rate_limit'
  | 'permission_denied'
  | 'suspicious_activity'
  | 'credential_access'
  | 'api_key_used';

export interface SecurityEvent {
  type: SecurityEventType;
  severity: 'low' | 'medium' | 'high' | 'critical';
  source?: string;
  description: string;
  details?: Record<string, unknown>;
  userId?: string;
  traceId?: string;
}

/**
 * Log a security event
 */
export async function logSecurityEvent(event: SecurityEvent): Promise<void> {
  const timestamp = new Date().toISOString();
  const logEntry = {
    timestamp,
    ...event,
  };
  
  // Log to console (in production, send to security monitoring service)
  console.log('[SECURITY]', JSON.stringify(logEntry));
  
  // In production, also send to:
  // - Security monitoring service (e.g., Datadog, Splunk)
  // - SIEM system
  // - Alert system for critical events
}

// ============================================================================
// EXPORT ALL
// ============================================================================

export const Security = {
  CredentialVault,
  InputValidator,
  PromptInjectionDetector,
  RateLimiter,
  TokenGenerator,
  PermissionChecker,
  logSecurityEvent,
  PERMISSIONS,
};

export default Security;
