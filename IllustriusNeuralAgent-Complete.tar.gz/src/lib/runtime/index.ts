/**
 * Agent Runtime Module
 * 
 * The core execution engine for the AI agent. Manages:
 * - Conversation flow
 * - Message processing
 * - Skill execution
 * - LLM interactions
 * - Memory integration
 * - Response generation
 * 
 * Security features:
 * - Sandboxed skill execution
 * - Input validation
 * - Rate limiting
 * - Audit logging
 */

import { db } from '../db';
import {
  Agent,
  AgentConfig,
  Conversation,
  Message,
  ConversationContext,
  LLMRequest,
  LLMResponse,
  SkillContext,
  AgentError,
  SkillError,
} from '../types';
import { getLLMGateway, estimateTokens } from '../llm/gateway';
import { MemoryManager, ContextBuilder } from '../memory/manager';
import { Security, InputValidator, PromptInjectionDetector, TokenGenerator } from '../security';

// ============================================================================
// CONFIGURATION
// ============================================================================

const RUNTIME_CONFIG = {
  maxConversationLength: 100, // Maximum messages in a conversation
  defaultSystemPrompt: `You are a helpful AI assistant with persistent memory and skills.
You can remember past conversations and learn from them.
You have access to various skills that help you accomplish tasks.
Always be helpful, accurate, and safe.
When using tools, provide clear and structured outputs.`,
  maxRetries: 3,
  retryDelay: 1000,
  timeout: 60000, // 60 seconds
};

// ============================================================================
// AGENT RUNTIME
// ============================================================================

export interface RuntimeContext {
  agent: Agent;
  conversation: Conversation | null;
  memory: MemoryManager;
  contextBuilder: ContextBuilder;
}

/**
 * Main Agent Runtime class
 */
export class AgentRuntime {
  private agentId: string;
  private config: AgentConfig;
  private memory: MemoryManager;
  private contextBuilder: ContextBuilder;
  private conversation: Conversation | null = null;
  
  constructor(agentId: string, config: AgentConfig) {
    this.agentId = agentId;
    this.config = config;
    this.memory = new MemoryManager(agentId);
    this.contextBuilder = new ContextBuilder(this.memory);
  }
  
  /**
   * Initialize or load a conversation
   */
  async initializeConversation(conversationId?: string): Promise<Conversation> {
    if (conversationId) {
      const existing = await db.conversation.findUnique({
        where: { id: conversationId },
        include: { messages: true },
      });
      
      if (existing && existing.agentId === this.agentId) {
        this.conversation = existing as unknown as Conversation;
        return this.conversation;
      }
    }
    
    // Create new conversation
    const newConversation = await db.conversation.create({
      data: {
        agentId: this.agentId,
        platform: 'web',
        status: 'active',
        context: JSON.stringify({
          preferences: {},
          variables: {},
          activeSkills: this.config.skills,
        }),
      },
      include: { messages: true },
    });
    
    this.conversation = newConversation as unknown as Conversation;
    return this.conversation;
  }
  
  /**
   * Process an incoming message
   */
  async processMessage(
    content: string,
    platform: string = 'web',
    userId?: string
  ): Promise<Message> {
    const traceId = TokenGenerator.generateTraceId();
    
    try {
      // Ensure conversation exists
      if (!this.conversation) {
        await this.initializeConversation();
      }
      
      // Validate and sanitize input
      const sanitizedContent = InputValidator.sanitize(content);
      
      // Check for prompt injection
      const injectionCheck = PromptInjectionDetector.detect(sanitizedContent);
      if (injectionCheck.isInjection) {
        await Security.logSecurityEvent({
          type: 'prompt_injection',
          severity: 'high',
          description: 'Potential prompt injection detected',
          details: { score: injectionCheck.score, matches: injectionCheck.matches },
          userId,
          traceId,
        });
        
        // Still process but with wrapped input
        content = PromptInjectionDetector.wrapInput(sanitizedContent);
      }
      
      // Store user message
      const userMessage = await this.storeMessage('user', sanitizedContent, traceId);
      
      // Update working memory with user message
      await this.memory.add(
        `User: ${sanitizedContent}`,
        'working',
        { conversationId: this.conversation!.id, platform }
      );
      
      // Build context from memory
      const context = await this.contextBuilder.buildContext(sanitizedContent);
      
      // Get conversation history
      const history = await this.getConversationHistory();
      
      // Build messages for LLM
      const messages = this.buildLLMMessages(history, context, sanitizedContent);
      
      // Get LLM response
      const llmGateway = getLLMGateway();
      const response = await llmGateway.complete({
        messages,
        model: this.config.model,
        provider: this.config.provider,
        temperature: this.config.temperature ?? 0.7,
        maxTokens: this.config.maxTokens ?? 4096,
      });
      
      // Process tool calls if any
      let finalContent = response.content;
      if (response.toolCalls && response.toolCalls.length > 0) {
        finalContent = await this.processToolCalls(response.toolCalls, traceId);
      }
      
      // Store assistant message
      const assistantMessage = await this.storeMessage('assistant', finalContent, traceId, {
        tokenCount: response.usage.totalTokens,
        toolCalls: response.toolCalls,
      });
      
      // Update memory with conversation
      await this.memory.add(
        `Assistant: ${finalContent}`,
        'working',
        { conversationId: this.conversation!.id, response }
      );
      
      return assistantMessage;
      
    } catch (error) {
      // Log error
      console.error('[RUNTIME_ERROR]', error);
      
      // Store error message
      const errorMessage = await this.storeMessage(
        'assistant',
        'I apologize, but I encountered an error processing your request. Please try again.',
        traceId,
        { error: error instanceof Error ? error.message : 'Unknown error' }
      );
      
      return errorMessage;
    }
  }
  
  /**
   * Process tool calls from LLM
   */
  private async processToolCalls(
    toolCalls: Array<{ id: string; name: string; arguments: Record<string, unknown> }>,
    traceId: string
  ): Promise<string> {
    const results: string[] = [];
    
    for (const toolCall of toolCalls) {
      try {
        // Get skill from database
        const skill = await db.skill.findFirst({
          where: { name: toolCall.name, isActive: true },
        });
        
        if (!skill) {
          results.push(`Tool ${toolCall.name} not found.`);
          continue;
        }
        
        // Create execution record
        const execution = await db.skillExecution.create({
          data: {
            skillId: skill.id,
            conversationId: this.conversation?.id,
            input: JSON.stringify(toolCall.arguments),
            status: 'running',
          },
        });
        
        // Execute skill (in production, this would be sandboxed)
        const startTime = Date.now();
        let output: string;
        
        try {
          output = await this.executeSkill(skill.code, toolCall.arguments);
          
          await db.skillExecution.update({
            where: { id: execution.id },
            data: {
              output,
              status: 'success',
              duration: Date.now() - startTime,
            },
          });
          
          results.push(`[${toolCall.name}]: ${output}`);
        } catch (skillError) {
          await db.skillExecution.update({
            where: { id: execution.id },
            data: {
              status: 'error',
              errorMessage: skillError instanceof Error ? skillError.message : 'Unknown error',
              duration: Date.now() - startTime,
            },
          });
          
          results.push(`[${toolCall.name}]: Error - ${skillError instanceof Error ? skillError.message : 'Unknown error'}`);
        }
        
      } catch (error) {
        results.push(`[${toolCall.name}]: Failed to execute - ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
    }
    
    return results.join('\n\n');
  }
  
  /**
   * Execute a skill in a sandboxed environment
   */
  private async executeSkill(
    code: string,
    args: Record<string, unknown>
  ): Promise<string> {
    // In production, this would use a proper sandbox (e.g., VM2, isolated-vm)
    // For now, we'll use a simple function evaluation
    
    try {
      // Create skill function
      const skillFunction = new Function('args', 'context', `
        ${code}
        return execute(args, context);
      `);
      
      // Create minimal context
      const context = {
        agentId: this.agentId,
        conversationId: this.conversation?.id,
      };
      
      // Execute with timeout
      const result = await Promise.race([
        Promise.resolve(skillFunction(args, context)),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Skill execution timeout')), RUNTIME_CONFIG.timeout)
        ),
      ]);
      
      return typeof result === 'string' ? result : JSON.stringify(result);
      
    } catch (error) {
      throw new SkillError(
        error instanceof Error ? error.message : 'Skill execution failed',
        'skill_execution',
        'E4001',
        { code: code.substring(0, 200), args }
      );
    }
  }
  
  /**
   * Store a message in the conversation
   */
  private async storeMessage(
    role: 'user' | 'assistant' | 'system' | 'tool',
    content: string,
    traceId: string,
    metadata: Record<string, unknown> = {}
  ): Promise<Message> {
    if (!this.conversation) {
      throw new AgentError('No active conversation', 'E4002');
    }
    
    const message = await db.message.create({
      data: {
        conversationId: this.conversation.id,
        role,
        content,
        tokenCount: estimateTokens(content),
        metadata: JSON.stringify(metadata),
        traceId,
      },
    });
    
    return message as unknown as Message;
  }
  
  /**
   * Get conversation history
   */
  private async getConversationHistory(limit: number = 20): Promise<Message[]> {
    if (!this.conversation) return [];
    
    const messages = await db.message.findMany({
      where: { conversationId: this.conversation.id },
      orderBy: { createdAt: 'desc' },
      take: limit,
    });
    
    return messages.reverse() as unknown as Message[];
  }
  
  /**
   * Build messages array for LLM
   */
  private buildLLMMessages(
    history: Message[],
    context: string,
    currentMessage: string
  ): LLMRequest['messages'] {
    const messages: LLMRequest['messages'] = [];
    
    // System prompt
    const systemPrompt = this.config.systemPrompt || RUNTIME_CONFIG.defaultSystemPrompt;
    messages.push({
      role: 'system',
      content: `${systemPrompt}\n\n${context ? `Context:\n${context}` : ''}`,
    });
    
    // Conversation history
    for (const msg of history) {
      messages.push({
        role: msg.role as 'user' | 'assistant' | 'system',
        content: msg.content,
      });
    }
    
    // Current message
    messages.push({
      role: 'user',
      content: currentMessage,
    });
    
    return messages;
  }
  
  /**
   * Get current conversation
   */
  getConversation(): Conversation | null {
    return this.conversation;
  }
  
  /**
   * Clear conversation history
   */
  async clearConversation(): Promise<void> {
    if (!this.conversation) return;
    
    await db.message.deleteMany({
      where: { conversationId: this.conversation.id },
    });
    
    // Clear working memory
    this.memory = new MemoryManager(this.agentId);
    this.contextBuilder = new ContextBuilder(this.memory);
  }
  
  /**
   * Update agent configuration
   */
  async updateConfig(newConfig: Partial<AgentConfig>): Promise<void> {
    this.config = { ...this.config, ...newConfig };
    
    await db.agent.update({
      where: { id: this.agentId },
      data: { config: JSON.stringify(this.config) },
    });
  }
}

// ============================================================================
// RUNTIME FACTORY
// ============================================================================

const runtimeCache: Map<string, AgentRuntime> = new Map();

/**
 * Get or create a runtime for an agent
 */
export async function getRuntime(agentId: string): Promise<AgentRuntime> {
  if (runtimeCache.has(agentId)) {
    return runtimeCache.get(agentId)!;
  }
  
  // Load agent from database
  const agent = await db.agent.findUnique({
    where: { id: agentId },
  });
  
  if (!agent) {
    throw new AgentError(`Agent ${agentId} not found`, 'E4003');
  }
  
  const config = JSON.parse(agent.config as string) as AgentConfig;
  const runtime = new AgentRuntime(agentId, config);
  
  runtimeCache.set(agentId, runtime);
  
  return runtime;
}

/**
 * Create a new agent with configuration
 */
export async function createAgent(
  userId: string,
  name: string,
  config: Partial<AgentConfig>
): Promise<Agent> {
  const defaultConfig: AgentConfig = {
    model: 'gpt-4o',
    provider: 'openai',
    skills: [],
    memory: {
      enabled: true,
      workingMemorySize: 50,
      episodicRetention: 90,
      semanticEmbedding: true,
      compressionEnabled: true,
    },
    security: {
      sandboxMode: true,
      allowedDomains: [],
      maxExecutionTime: 60000,
      maxMemoryMB: 256,
      requireApproval: ['critical'],
    },
    rateLimits: {
      requestsPerMinute: 60,
      tokensPerMinute: 100000,
      requestsPerDay: 1000,
    },
  };
  
  const agent = await db.agent.create({
    data: {
      userId,
      name,
      config: JSON.stringify({ ...defaultConfig, ...config }),
      status: 'idle',
    },
  });
  
  return agent as unknown as Agent;
}

export default AgentRuntime;
