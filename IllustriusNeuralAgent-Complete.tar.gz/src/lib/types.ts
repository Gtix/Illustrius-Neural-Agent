/**
 * Core Type Definitions for the AI Agent Platform
 * 
 * This module defines all the core types, interfaces, and enums
 * used throughout the system.
 */

// ============================================================================
// MESSAGE TYPES
// ============================================================================

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system' | 'tool';
  content: string;
  timestamp: Date;
  tokenCount?: number;
  metadata?: MessageMetadata;
  traceId?: string;
}

export interface MessageMetadata {
  toolCalls?: ToolCall[];
  toolResults?: ToolResult[];
  platform?: Platform;
  externalId?: string;
  attachments?: Attachment[];
  replyTo?: string;
}

export interface ToolCall {
  id: string;
  name: string;
  arguments: Record<string, unknown>;
}

export interface ToolResult {
  toolCallId: string;
  result: unknown;
  error?: string;
}

export interface Attachment {
  type: 'image' | 'file' | 'audio' | 'video';
  url: string;
  name?: string;
  mimeType?: string;
  size?: number;
}

// ============================================================================
// PLATFORM TYPES
// ============================================================================

export type Platform = 
  | 'web' 
  | 'whatsapp' 
  | 'telegram' 
  | 'discord' 
  | 'email' 
  | 'slack'
  | 'sms';

export interface PlatformMessage {
  id: string;
  platform: Platform;
  externalId: string;
  conversationId: string;
  senderId: string;
  senderName?: string;
  content: string;
  attachments?: Attachment[];
  timestamp: Date;
  metadata?: Record<string, unknown>;
}

export interface PlatformConnection {
  id: string;
  platform: Platform;
  externalId?: string;
  credentials: Record<string, string>;
  config: Record<string, unknown>;
  isActive: boolean;
  lastSync?: Date;
}

// ============================================================================
// CONVERSATION TYPES
// ============================================================================

export interface Conversation {
  id: string;
  agentId: string;
  platform: Platform;
  externalId?: string;
  status: ConversationStatus;
  messages: Message[];
  context: ConversationContext;
  metadata: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export type ConversationStatus = 'active' | 'archived' | 'deleted';

export interface ConversationContext {
  userId?: string;
  userName?: string;
  preferences: Record<string, unknown>;
  variables: Record<string, unknown>;
  activeSkills: string[];
}

// ============================================================================
// AGENT TYPES
// ============================================================================

export interface Agent {
  id: string;
  name: string;
  description?: string;
  status: AgentStatus;
  version: string;
  config: AgentConfig;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
}

export type AgentStatus = 'idle' | 'running' | 'paused' | 'error';

export interface AgentConfig {
  model: string;
  provider: string;
  systemPrompt?: string;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
  skills: string[];
  memory: MemoryConfig;
  security: SecurityConfig;
  rateLimits: RateLimitConfig;
}

export interface MemoryConfig {
  enabled: boolean;
  workingMemorySize: number;
  episodicRetention: number; // days
  semanticEmbedding: boolean;
  compressionEnabled: boolean;
}

export interface SecurityConfig {
  sandboxMode: boolean;
  allowedDomains: string[];
  maxExecutionTime: number; // ms
  maxMemoryMB: number;
  requireApproval: string[]; // skill categories requiring approval
}

export interface RateLimitConfig {
  requestsPerMinute: number;
  tokensPerMinute: number;
  requestsPerDay: number;
}

// ============================================================================
// SKILL TYPES
// ============================================================================

export interface Skill {
  id: string;
  name: string;
  displayName: string;
  description: string;
  version: string;
  category: SkillCategory;
  authorId?: string;
  code: string;
  schema: SkillSchema;
  permissions: string[];
  securityLevel: SecurityLevel;
  isVerified: boolean;
  isActive: boolean;
  downloads: number;
  rating: number;
  createdAt: Date;
  updatedAt: Date;
}

export type SkillCategory = 
  | 'communication'
  | 'automation'
  | 'data'
  | 'productivity'
  | 'entertainment'
  | 'development'
  | 'integration'
  | 'general';

export type SecurityLevel = 'low' | 'standard' | 'high' | 'critical';

export interface SkillSchema {
  input: {
    type: string;
    properties: Record<string, SchemaProperty>;
    required?: string[];
  };
  output: {
    type: string;
    properties: Record<string, SchemaProperty>;
  };
}

export interface SchemaProperty {
  type: string;
  description?: string;
  enum?: string[];
  default?: unknown;
}

export interface SkillExecution {
  id: string;
  skillId: string;
  conversationId?: string;
  input: Record<string, unknown>;
  output?: Record<string, unknown>;
  status: ExecutionStatus;
  errorMessage?: string;
  duration?: number;
  tokensUsed: number;
  createdAt: Date;
}

export type ExecutionStatus = 'pending' | 'running' | 'success' | 'error';

export interface SkillContext {
  agent: Agent;
  conversation: Conversation;
  message: Message;
  user?: { id: string; name?: string; email?: string };
  memory: MemoryInterface;
  llm: LLMInterface;
}

// ============================================================================
// MEMORY TYPES
// ============================================================================

export interface Memory {
  id: string;
  agentId: string;
  type: MemoryType;
  category?: string;
  content: string;
  embedding?: number[];
  importance: number;
  accessCount: number;
  lastAccessed?: Date;
  expiresAt?: Date;
  metadata: Record<string, unknown>;
  createdAt: Date;
  updatedAt: Date;
}

export type MemoryType = 'working' | 'episodic' | 'semantic';

export interface MemoryInterface {
  add(content: string, type: MemoryType, metadata?: Record<string, unknown>): Promise<Memory>;
  search(query: string, limit?: number): Promise<Memory[]>;
  get(id: string): Promise<Memory | null>;
  update(id: string, data: Partial<Memory>): Promise<Memory>;
  delete(id: string): Promise<void>;
  compress(): Promise<void>;
  getWorkingMemory(): Promise<Memory[]>;
}

// ============================================================================
// LLM TYPES
// ============================================================================

export interface LLMProvider {
  id: string;
  name: string;
  displayName: string;
  baseUrl?: string;
  isActive: boolean;
  config: Record<string, unknown>;
  rateLimit: number;
}

export interface ModelConfig {
  id: string;
  providerId: string;
  modelName: string;
  displayName: string;
  contextWindow: number;
  maxOutput: number;
  inputCost: number;
  outputCost: number;
  supportsVision: boolean;
  supportsTools: boolean;
  isActive: boolean;
}

export interface LLMRequest {
  messages: LLMMessage[];
  model: string;
  provider: string;
  temperature?: number;
  maxTokens?: number;
  topP?: number;
  stop?: string[];
  tools?: LLMTool[];
  toolChoice?: 'auto' | 'none' | { type: 'function'; function: { name: string } };
  stream?: boolean;
  metadata?: Record<string, unknown>;
}

export interface LLMMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | LLMContentPart[];
  name?: string;
  toolCallId?: string;
  toolCalls?: ToolCall[];
}

export interface LLMContentPart {
  type: 'text' | 'image_url';
  text?: string;
  imageUrl?: { url: string };
}

export interface LLMTool {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}

export interface LLMResponse {
  id: string;
  provider: string;
  model: string;
  content: string;
  toolCalls?: ToolCall[];
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  finishReason: 'stop' | 'length' | 'tool_calls' | 'content_filter';
  duration: number;
}

export interface LLMInterface {
  complete(request: LLMRequest): Promise<LLMResponse>;
  stream(request: LLMRequest): AsyncIterable<LLMStreamChunk>;
  countTokens(text: string): number;
}

export interface LLMStreamChunk {
  content: string;
  toolCalls?: Partial<ToolCall>[];
  finishReason?: string;
}

// ============================================================================
// ERROR TYPES
// ============================================================================

export class AgentError extends Error {
  constructor(
    message: string,
    public code: string,
    public details?: Record<string, unknown>,
    public recoverable: boolean = true
  ) {
    super(message);
    this.name = 'AgentError';
  }
}

export class SkillError extends AgentError {
  constructor(
    message: string,
    public skillId: string,
    code: string,
    details?: Record<string, unknown>
  ) {
    super(message, code, details, true);
    this.name = 'SkillError';
  }
}

export class SecurityError extends AgentError {
  constructor(
    message: string,
    code: string,
    details?: Record<string, unknown>
  ) {
    super(message, code, details, false);
    this.name = 'SecurityError';
  }
}

export class RateLimitError extends AgentError {
  constructor(
    message: string,
    public retryAfter: number,
    details?: Record<string, unknown>
  ) {
    super(message, 'RATE_LIMIT_EXCEEDED', details, true);
    this.name = 'RateLimitError';
  }
}

// ============================================================================
// UTILITY TYPES
// ============================================================================

export interface PaginationParams {
  page: number;
  limit: number;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

export interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface SearchResult<T> {
  items: T[];
  query: string;
  total: number;
  duration: number;
}

export type AsyncResult<T, E = Error> = 
  | { success: true; data: T }
  | { success: false; error: E };

export type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};

export type WithRequired<T, K extends keyof T> = T & { [P in K]-?: T[P] };

export type WithOptional<T, K extends keyof T> = Omit<T, K> & Partial<Pick<T, K>>;
